--leak by matveicher
--vk group - https://vk.com/codespill
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/7XaRzQSZ45
--ds - matveicher

--[[

Author: tochnonement
Email: tochnonement@gmail.com

05/06/2022

--]]

onyx.IncludeFolder('onyx/ui/libs/thirdparty/')
onyx.IncludeFolder('onyx/ui/libs/')
onyx.IncludeFolder('onyx/ui/cfg/', true)
onyx.IncludeFolder('onyx/ui/core/', true)
onyx.IncludeFolder('onyx/ui/traits/', true)
onyx.IncludeFolder('onyx/ui/elements/', true)

--leak by matveicher
--vk group - https://vk.com/codespill
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/7XaRzQSZ45
--ds - matveicher
