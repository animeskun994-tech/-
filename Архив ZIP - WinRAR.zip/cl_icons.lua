--leak by matveicher
--vk group - https://vk.com/codespill
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/7XaRzQSZ45
--ds - matveicher

--[[

Author: tochnonement
Email: tochnonement@gmail.com

14/08/2024

--]]

onyx.wimg.Register( 'hud_microphone', 'https://i.imgur.com/gcM94Fk.png' ) -- 128x128
onyx.wimg.Register( 'hud_chat', 'https://i.imgur.com/q5Lw2qs.png' ) -- 128x128
onyx.wimg.Register( 'hud_connection_lost', 'https://i.imgur.com/EoFpsnf.png' ) -- 128x128

-- 64x64
onyx.wimg.Register( 'hud_wanted', 'https://i.imgur.com/rFyMifb.png' ) 
onyx.wimg.Register( 'hud_license', 'https://i.imgur.com/gltIVYm.png' )
onyx.wimg.Register( 'hud_food', 'https://i.imgur.com/PBZSeVr.png' )
onyx.wimg.Register( 'hud_shield', 'https://i.imgur.com/6Bvc6jX.png' )
onyx.wimg.Register( 'hud_heart', 'https://i.imgur.com/p5Ydzmp.png' )
onyx.wimg.Register( 'hud_lockdown', 'https://i.imgur.com/4K2lTOO.png' )
onyx.wimg.Register( 'hud_arrested', 'https://i.imgur.com/7WVcWRg.png' )

onyx.wimg.Register( 'radial_close', 'https://i.imgur.com/O2fDo4C.png' )
onyx.wimg.Register( 'door_sell', 'https://i.imgur.com/sk1wknE.png' )
onyx.wimg.Register( 'door_title', 'https://i.imgur.com/ShyxozE.png' )
onyx.wimg.Register( 'door_add_user', 'https://i.imgur.com/MMBU6Qg.png' )
onyx.wimg.Register( 'door_remove_user', 'https://i.imgur.com/veLnn9Z.png' )
onyx.wimg.Register( 'door_disable_own', 'https://i.imgur.com/jbItdgJ.png' )
onyx.wimg.Register( 'door_enable_own', 'https://i.imgur.com/B2sTNGW.png' )
onyx.wimg.Register( 'door_own', 'https://i.imgur.com/tCUFyic.png' )
onyx.wimg.Register( 'door_groups', 'https://i.imgur.com/ttokI0C.png' )


--leak by matveicher
--vk group - https://vk.com/codespill
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/7XaRzQSZ45
--ds - matveicher
